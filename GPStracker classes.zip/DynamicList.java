package ca.georgebrown.comp3074.gpstracker;

import java.util.ArrayList;
import java.util.Collections;

public class DynamicList {

    public ArrayList<DonorOnline> donors ;
    private UserManager.User needed;

    public DynamicList(UserManager.User needed) {
        this.needed = needed;
        donors = new ArrayList<DonorOnline>();
    }

    public  void addDonor(UserManager.User donor) {

        DonorOnline donorOnline = new DonorOnline(donor);
        donorOnline.setDistance(calculateDistance(donor) );
        donors.add(donorOnline);
    }

    private double calculateDistance(UserManager.User donor ) {

        double latitud1 = Double.parseDouble(needed.latitud);
        double longitud1 = Double.parseDouble(needed.longitud);
        double latitud2 = Double.parseDouble(donor.latitud);
        double longitud2 = Double.parseDouble(donor.longitud);

        double latDistance = (latitud2 - latitud1) * (latitud2 - latitud1);
        double lonDistance = (longitud2 - longitud1) * (longitud2 - longitud1);
        return  Math.sqrt(latDistance + lonDistance) * 111;

    }

    public ArrayList<DonorOnline> sortedDonorsOnline() {
        Collections.sort(donors, DonorOnline.sortByDistance);
        return donors;
    }







}
