package ca.georgebrown.comp3074.gpstracker;

public class Food {

    public static class FoodUser {

        public String food_name;
        public String category;
        public String expiry_date;
        public String ingredients;
        public String email;

        public FoodUser(String food_name,
                        String category,
                        String expiry_date,
                        String ingredients,
                        String email) {

            this.food_name = food_name;
            this.category = category;
            this.expiry_date = expiry_date;
            this.ingredients = ingredients;
            this.email = email;

        }


        public String getFood_name() {
            return food_name;
        }

        public void setFood_name(String food_name) {
            this.food_name = food_name;
        }

        public String getCategory() {
            return category;
        }

        public void setCategory(String category) {
            this.category = category;
        }

        public String getExpiry_date() {
            return expiry_date;
        }

        public void setExpiry_date(String expiry_date) {
            this.expiry_date = expiry_date;
        }

        public String getIngredients() {
            return ingredients;
        }

        public void setIngredients(String ingredients) {
            this.ingredients = ingredients;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String toString() {
            return  food_name;
        }
    }
}
