package ca.georgebrown.comp3074.gpstracker;

import java.util.Comparator;

public class DonorOnline {

    public UserManager.User donorOnline;
    public double distance;

    public DonorOnline(UserManager.User donorOnline) {
        this.donorOnline = donorOnline;
        distance = 0;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public static Comparator<DonorOnline> sortByDistance = new Comparator<DonorOnline>() {

        @Override
        public int compare(DonorOnline user1, DonorOnline user2) {
            double d = user1.distance - user2.distance;
            if (d > 0) return 1;
            if (d < 0) return -1;
            return 0;
        }
    };

    public String toString() {
        return donorOnline.first_name + " " + donorOnline.last_name + " " + distance + " " + donorOnline.foods;
    }

}