package ca.georgebrown.comp3074.gpstracker;

public class Point {
}
