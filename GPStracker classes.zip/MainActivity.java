package ca.georgebrown.comp3074.gpstracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button btnGetLoc;
    TextView txtLocation;
    static UserManager.User user;

    public ArrayList<Food.FoodUser> generateData(String lat, String lon) {
        ArrayList<Food.FoodUser> foodList = new ArrayList<>();

        // toronto  43.6532° N, 79.3832° W
        // casa loma 43.6780° N, 79.4094° W
        // north york 43.7615° N, 79.4111° W

        // user 1
        String email = "alejandro@gbc.ca";
        user = UserManager.createUser(email, "alejandro", "user_a", "1234", "1234", "abc", "d", "0");
        UserManager.USERS.add(user);
        Food.FoodUser f = new Food.FoodUser("bread", "Vegetable", "2020/02/15", "flour", email);
        UserManager.getUser(email).addFood(f);
        UserManager.User user1 = UserManager.getUser(email);
        user1.latitud = "43.6780";
        user1.longitud = "-79.4094";

        // user 2
        email = "steeven@gbc.ca";
        user = UserManager.createUser(email, "Steeven", "user_b", "4321", "4321", "cba", "e", "1");
        UserManager.USERS.add(user);
        f = new Food.FoodUser("rice", "vegetable", "2020/02/25", "rice", email);
        UserManager.getUser(email).addFood(f);
        f = new Food.FoodUser("beans", "vegetable", "2020/01/15", "beans", email);
        UserManager.getUser(email).addFood(f);
        UserManager.User user2 = UserManager.getUser(email);
        user2.latitud = "43.6780";
        user2.longitud = "-79.2194";

        // user 3
        email = "hristo@gbc.ca";
        user = UserManager.createUser(email, "Hristo", "user_c", "4321", "4321", "cba", "e", "1");
        UserManager.USERS.add(user);
        f = new Food.FoodUser("potato", "vegetable", "2020/02/25", "potato", email);
        UserManager.getUser(email).addFood(f);
        f = new Food.FoodUser("coke", "beverage", "2020/01/15", "sugar", email);
        UserManager.getUser(email).addFood(f);
        UserManager.User user3 = UserManager.getUser(email);
        user3.latitud = "43.6720";
        user3.longitud = "-79.4100";


        // user 4
        email = "vivek@gbc.ca";
        user = UserManager.createUser(email, "vivek", "user_d", "4321", "4321", "cba", "f", "11");
        UserManager.USERS.add(user);
        f = new Food.FoodUser("banana", "vegetable", "2020/02/25", "banana", email);
        UserManager.getUser(email).addFood(f);
        f = new Food.FoodUser("coke", "beverage", "2020/01/15", "sugar", email);
        UserManager.getUser(email).addFood(f);
        f = new Food.FoodUser("milk", "diary", "2020/01/15", "milk", email);

        UserManager.getUser(email).addFood(f);
        UserManager.User user4 = UserManager.getUser(email);
        user4.latitud = "43.6780";
        user4.longitud = "-79.4001";

        // Needed
        user = UserManager.createUser("needed@gbc.ca", "Needed", "Foot", "pass", "5678", "def", "n", "2");
        UserManager.USERS.add(user);
        //Food.FoodUser f4 = new Food.FoodUser("bread2", "Dinner", "2020/02/25", "flour", "needed@gbc.ca");
        //UserManager.getUser("needed@gbc.ca").addFood(f4);
        UserManager.User needed = UserManager.getUser("needed@gbc.ca");
        needed.latitud = lat;
        needed.longitud = lon;

        System.out.println();

        DynamicList dynamicList = new DynamicList(needed);
        dynamicList.addDonor(user1);
        dynamicList.addDonor(user2);
        dynamicList.addDonor(user3);
        dynamicList.addDonor(user4);
        dynamicList.sortedDonorsOnline();

        int count = 0;
        for (DonorOnline donor : dynamicList.donors)
            for (Food.FoodUser food : donor.donorOnline.foods)
                System.out.println(++count + ". " + food + " - " + donor.donorOnline.first_name + " @ " + String.format("%.1f", donor.distance) + "km");

        return foodList;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnGetLoc = findViewById(R.id.btnGetLocation);
        txtLocation = findViewById(R.id.textViewLocation);

        ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION}, 123);
        btnGetLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                GPStracker g = new GPStracker(getApplicationContext());
                Location l = g.getLocation();

                double lat = 0;
                double lon = 0;
                if (l != null) {
                    lat = l.getLatitude();
                    lon = l.getLongitude();
                    txtLocation.setText("[ " + String.format("%.4f", lat) + ", " + String.format("%.4f", lon) + " ]");
                }

                ArrayList<Food.FoodUser> list = generateData(Double.toString(lat), Double.toString(lon));

                for (Food.FoodUser item : list) {
                    // User.UserOnline user = new User.UserOnline();
                    System.out.println(item);
                }


                SecurePasswordStorage passManager = new SecurePasswordStorage();
                String userName = "admin";
                String password = "password";
                try {
                    passManager.signUp(userName, password);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                userName = "admin1";
                password = "password";
                try {
                    passManager.signUp(userName, password);
                } catch (Exception e) {
                    e.printStackTrace();
                }


                System.out.println("Please enter username:");
                String inputUser = "admin";

                System.out.println("Please enter password:");
                String inputPass = "password";

                boolean status = false;
                try {
                    status = passManager.authenticateUser(inputUser, inputPass);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (status) {
                    System.out.println("Logged in!");
                } else {
                    System.out.println("Sorry, wrong username/password");
                }


            }
        });
    }
}
